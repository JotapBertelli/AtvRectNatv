import { View, Text } from 'react-native';

function Calculadora({ num1, num2, operacao }) {
  var resultado;
  
  switch (operacao) {
    case 'soma':
      resultado = num1 + num2;
      break;
    case 'subtracao':
      resultado = num1 - num2;
      break;
    case 'multiplicacao':
      resultado = num1 * num2;
      break;
    case 'divisao':
      resultado = num1 / num2;
      break;
    default:
      resultado = 'Operação inválida';
  }

  return (
    <View>
      <Text>O resultado da operação {operacao} entre {num1} e {num2} é:</Text>
      <Text>{resultado}</Text>
    </View>
  );
}

export default Calculadora;

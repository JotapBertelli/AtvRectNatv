import { Text, SafeAreaView } from 'react-native';
import { estilo } from './assets/CSS/estilo';
import Calculadora from './components/Calculadora'; 
function App() {
  return (
    <SafeAreaView style={estilo.container}>
      <Text style={estilo.texto}>Número:</Text>
      <Calculadora num1={5} num2={3} operacao="soma" />
    </SafeAreaView>
  );
}

export default App;

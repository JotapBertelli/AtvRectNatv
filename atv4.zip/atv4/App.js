import { Text, SafeAreaView } from 'react-native';
import { estilo } from './assets/CSS/estilo'; 
import Soma from './components/Soma';

function App() {
  return (
    <SafeAreaView style={estilo.container}>
      <Text style={estilo.texto}>Maior Numero:</Text>
      <Soma num1={8} num2={4} num3={6} />
    </SafeAreaView>
  );
}

export default App;

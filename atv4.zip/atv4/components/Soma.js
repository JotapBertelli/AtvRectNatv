import { View, Text } from 'react-native';

function Soma({ num1, num2, num3 }) {
  var SomaNumero = num1;

  if (num2 > SomaNumero) {
    SomaNumero = num2;
  }

  if (num3 > SomaNumero) {
    maiorNumero = num3;
  }

  var soma = num1 + num2 + num3;

  return (
    <View>
      <Text>A soma dos três números é: {soma}</Text>
    </View>
  );
}

export default Soma;

import { View, Text } from 'react-native';

function diviPor3({ numero }) {
  var divisivelPor3 = numero % 3 === 0;

  if (divisivelPor3) {
    return (
      <View>
        <Text>O número {numero} é divisível por 3.</Text>
      </View>
    );
  } else {
    return (
      <View>
        <Text>O número {numero} não é divisível por 3.</Text>
      </View>
    );
  }
}

export default diviPor3;

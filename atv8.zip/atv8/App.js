import React from 'react';
import { Text, SafeAreaView } from 'react-native';
import { estilo } from './assets/CSS/estilo'; 
import DivisivelPorTres from './components/DivisivelPorTres';

function App() {
  return (
    <SafeAreaView style={estilo.container}>
      <Text style={estilo.texto}>Número:</Text>
      <DivisivelPorTres numero={9} />
    </SafeAreaView>
  );
}

export default App;

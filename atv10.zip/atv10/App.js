import { Text, SafeAreaView } from 'react-native';
import { estilo } from './assets/CSS/estilo';
import MenorNumero from './components/MenorNumero'; 

function App() {
  return (
    <SafeAreaView style={estilo.container}>
      <Text style={estilo.texto}>Número:</Text>
      <MenorNumero num1={5} num2={3} num3={7} />
    </SafeAreaView>
  );
}

export default App;

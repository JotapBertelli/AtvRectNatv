import { View, Text } from 'react-native';

function MenorNumero({num1, num2, num3}) {
  var menorNumero = num1;
  if (num2 < menorNumero) {
    menorNumero = num2;
  }
  if (num3 < menorNumero) {
    menorNumero = num3;
  }

  return (
    <View>
      <Text>O menor número entre {num1}, {num2} e {num3} é:</Text>
      <Text>{menorNumero}</Text>
    </View>
  );
}

export default MenorNumero;

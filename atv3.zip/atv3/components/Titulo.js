import { View, Text } from 'react-native';
import { estilo } from '../assets/CSS/estilo';

function Titulo(props) {
  console.log()
  return (
    <View>
      <Text style={estilo.texto}>{props.principal}</Text>
      <Text>{props.secundario}</Text>
    </View>
  );
}

export default Titulo;

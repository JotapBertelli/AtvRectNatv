import { View, Text } from 'react-native';

function Maior({ num1, num2, num3 }) {
  let maiorNumero = num1;

  if (num2 > maiorNumero) {
    maiorNumero = num2;
  }

  if (num3 > maiorNumero) {
    maiorNumero = num3;
  }
  if (num1 === num2 && num2 === num3) {
    maiorNumero = 'os números são iguais';
}

  return (
    <View>
      <Text>O maior número é: {maiorNumero}</Text>
    </View>
  );
}

export default Maior;

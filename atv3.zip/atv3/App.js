import { Text, SafeAreaView } from 'react-native';
import { estilo } from './assets/CSS/estilo'; 
import Maior from './components/MaiorNumero';

function App() {
  return (
    <SafeAreaView style={estilo.container}>
      <Text style={estilo.texto}>Maior Numero:</Text>
      <Maior num1={1} num2={4} num3={1} />
    </SafeAreaView>
  );
}

export default App;

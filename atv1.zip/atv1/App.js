import React from 'react';
import { Text, SafeAreaView } from 'react-native';
import { estilo } from './assets/CSS/estilo'; 
import ParOuImpar from './components/Par';

function App() {
  return (
    <SafeAreaView style={estilo.container}>
      <Text style={estilo.texto}>Par ou impar:</Text>
      <ParOuImpar num1={2} num2={1} />
    </SafeAreaView>
  );
}

export default App;

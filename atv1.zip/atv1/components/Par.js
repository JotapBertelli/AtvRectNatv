import React from 'react';
import { View, Text } from 'react-native';

function ParOuImpar({ num1, num2 }) {
  let numeroPar;

  if (num1 % 2 === 0 && num2 % 2 === 0) {
    numeroPar = "Os dois numeros são iguais";
  } else if (num1 % 2 === 0) {
    numeroPar = num1;
  } else if (num2 % 2 === 0) {
    numeroPar = num2;
  } else {
    numeroPar = "Nenhum numero é par.";
  }

  return (
    <View>
      <Text>O número par é: {numeroPar}</Text>
    </View>
  );
}

export default ParOuImpar;

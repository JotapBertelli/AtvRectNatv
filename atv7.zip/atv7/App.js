import React from 'react';
import { Text, SafeAreaView } from 'react-native';
import { estilo } from './assets/CSS/estilo'; 
import PositivoOuNegativo from './components/PositivoOuNegativo';

function App() {
  return (
    <SafeAreaView style={estilo.container}>
      <Text style={estilo.texto}>Número:</Text>
      <PositivoOuNegativo numero={-1} />
    </SafeAreaView>
  );
}

export default App;

import { View, Text } from 'react-native';

function PositivoOuNegativo({numero}) {
  var mensagem;

  if (numero > 0) {
    mensagem = 'positivo';
  } else if (numero < 0) {
    mensagem = 'negativo';
  } else {
    mensagem = 'zero';
  }

  return (
    <View>
      <Text>O número {numero} é {mensagem}.</Text>
    </View>
  );
}

export default PositivoOuNegativo;

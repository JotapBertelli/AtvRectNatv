import { View, Text } from 'react-native';

function Negativo({ num1, num2 }) {
  let mensagem = '';

  if (num1 < 0 && num2 < 0) {
    mensagem = 'Os dois são negativos';
  } else if (num1 < 0 || num2 < 0) {
    mensagem = 'Algum dos numeros é negativo';
  } else {
    mensagem = 'Ambos são positivos ou zero.';
  }

  return (
    <View>
      <Text>{mensagem}</Text>
    </View>
  );
}

export default Negativo;

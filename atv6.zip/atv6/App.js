import { Text, SafeAreaView } from 'react-native';
import { estilo } from './assets/CSS/estilo'; 
import Multiplo from './components/MultiplosDeCinco';

function App() {
  return (
    <SafeAreaView style={estilo.container}>
      <Text style={estilo.texto}>Media:</Text>
      <Multiplo numero={25} />
    </SafeAreaView>
  );
}

export default App;

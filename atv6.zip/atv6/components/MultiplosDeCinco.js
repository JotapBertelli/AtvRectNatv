import { View, Text } from 'react-native';

function MultiploDeCinco({numero}) {
  return (
    <View>
      <Text>O número {numero} é {numero % 5 === 0 ? 'múltiplo' : 'não é múltiplo'} de 5.</Text>
    </View>
  );
}

export default MultiploDeCinco;
